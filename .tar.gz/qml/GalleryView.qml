import QtQuick
import QtQuick.Controls
import MediaGallery 1.0

// ─────────────────────────────────────────────────────────────────────────────
//  GalleryView.qml — Model/View-Galerie (Phase 2, Kernkomponente).
//
//  Ersetzt GalleryView(QScrollArea+QGridLayout). KEIN 1:1-Port: statt 1 Widget je
//  Datei recycelt ein GridView seine Delegates (reuseItems) und hält nur sichtbare
//  Kacheln im Speicher → flacher RAM-Verbrauch auch bei 10–50k Medien.
//
//  Daten kommen aus galleryModel (MediaProxyModel → MediaModel). Mutationen/
//  Thumbnail-Anforderungen laufen über mediaModel (per Dateipfad).
//
//  Erhaltene Features: dynamische Kachelgröße, Ctrl+Mausrad-Zoom, Anordnung
//  (Centered/Left/Right/Manual) inkl. Manual-Area-Breite, Doppelklick→Vollbild,
//  Inline-Rename (Overlay), Tag-Toggle, Group-/Add-to-Tag-Modus.
// ─────────────────────────────────────────────────────────────────────────────
Rectangle {
    id: root
    color: App.themeBackground

    // Vollbild-Anforderung an die Shell (Phase 3 füllt das Ziel).
    signal activated(string filePath)

    // ── View-Modi (Hook-Punkte für FilterBar/TagSystem in Phase 3) ──────────
    // 0 = none, 1 = group (Rechtsklick toggelt), 2 = addToTag (Linksklick toggelt)
    property int    tagMode: 0
    property string modeTag: ""

    function enterGroupMode(tag)     { modeTag = tag; tagMode = 1 }
    function enterAddToTagMode(tag)  { modeTag = tag; tagMode = 2 }
    function exitModes()             { modeTag = ""; tagMode = 0 }

    // ── Layout-Konstanten / abgeleitete Geometrie ───────────────────────────
    readonly property int margin: 12
    readonly property int spacing: 8
    readonly property int cellW: App.tileWidth + spacing
    readonly property int cellH: App.tileHeight + spacing

    readonly property int areaW: App.tileArrangement === 3   // Manual
                                 ? Math.min(App.manualAreaWidth, root.width - 2 * margin)
                                 : root.width - 2 * margin
    readonly property int columns: Math.max(1, Math.floor(areaW / cellW))
    readonly property int gridW: columns * cellW
    readonly property int gridX: {
        switch (App.tileArrangement) {
        case 1: return margin                              // Left
        case 2: return Math.max(margin, root.width - margin - gridW)  // Right
        default: return Math.max(margin, (root.width - gridW) / 2)    // Centered/Manual
        }
    }

    // ── Leerzustand ─────────────────────────────────────────────────────────
    Text {
        anchors.centerIn: parent
        visible: grid.count === 0
        width: Math.min(root.width - 48, 640)
        horizontalAlignment: Text.AlignHCenter
        wrapMode: Text.WordWrap
        text: App.currentFolder.length > 0
              ? "Keine anzeigbaren Medien in diesem Ordner."
              : "Kein Ordner geöffnet — Datei \u25B8 Ordner öffnen oder hierher ziehen."
        color: App.themeTextMuted
        font.pixelSize: 14
    }

    // ── Gitter ──────────────────────────────────────────────────────────────
    GridView {
        id: grid
        y: 0
        x: root.gridX
        width: root.gridW
        height: root.height
        clip: true

        cellWidth: root.cellW
        cellHeight: root.cellH

        model: galleryModel

        // RAM-Priorität: kleiner Cache-Puffer (≈ eine Extrazeile je Richtung).
        reuseItems: true
        cacheBuffer: root.cellH
        boundsBehavior: Flickable.StopAtBounds

        ScrollBar.vertical: ScrollBar { policy: ScrollBar.AsNeeded }

        delegate: Item {
            id: cell
            width: grid.cellWidth
            height: grid.cellHeight

            required property string filePath
            required property string displayName
            required property int    mediaType
            required property string typeLabel
            required property var    tags
            required property var    dateTime
            required property string thumbUrl
            required property int    thumbState

            // Sichtbarkeitsgesteuerte Thumbnail-Anforderung (auch bei Recycling).
            function requestThumb() {
                if (filePath.length > 0)
                    mediaModel.ensureThumbnail(filePath)
            }
            Component.onCompleted: requestThumb()
            onFilePathChanged: requestThumb()
            GridView.onReused: requestThumb()

            MediaTile {
                anchors.centerIn: parent
                width: App.tileWidth
                height: App.tileHeight

                filePath: cell.filePath
                displayName: cell.displayName
                mediaType: cell.mediaType
                typeLabel: cell.typeLabel
                tags: cell.tags
                dateTime: cell.dateTime
                thumbUrl: cell.thumbUrl
                thumbState: cell.thumbState

                tagMode: root.tagMode
                modeTag: root.modeTag

                onActivated: function(p) { root.activated(p) }
            }
        }
    }

    // ── Ctrl+Mausrad-Zoom ───────────────────────────────────────────────────
    // Akzeptiert nur mit Strg; ohne Modifier scrollt das GridView normal weiter.
    WheelHandler {
        acceptedModifiers: Qt.ControlModifier
        onWheel: function(event) {
            if (event.angleDelta.y > 0)      App.zoomIn(16)
            else if (event.angleDelta.y < 0) App.zoomOut(16)
        }
    }
}
