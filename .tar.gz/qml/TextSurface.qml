import QtQuick
import QtQuick.Controls
import MediaGallery 1.0

// ─────────────────────────────────────────────────────────────────────────────
//  TextSurface.qml — read-only Textanzeige (ersetzt TextViewer(QWidget); laut
//  Phase-3-Vorgabe bewusst nur lesend). Inhalt kommt über Viewer.readTextFile;
//  beim Verlassen gibt der Aufrufer release() → Puffer frei (RAM-Prio).
// ─────────────────────────────────────────────────────────────────────────────
Item {
    id: root

    property string source: ""

    function release() { view.text = "" }

    onSourceChanged: {
        view.text = source.length > 0 ? Viewer.readTextFile(source) : ""
        view.cursorPosition = 0
    }

    Rectangle { anchors.fill: parent; color: App.themeBackground }

    ScrollView {
        anchors.fill: parent
        anchors.margins: 12
        clip: true

        TextArea {
            id: view
            readOnly: true
            selectByMouse: true
            wrapMode: TextEdit.NoWrap
            color: App.themeTextPrimary
            font.family: "monospace"
            font.pixelSize: 13
            background: Rectangle { color: App.themeCard; radius: 6; border.color: App.themeBorder }
            padding: 10
        }
    }
}
