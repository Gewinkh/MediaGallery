pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Controls
import QtQuick.Pdf
import QtMultimedia
import MediaGallery 1.0

// ─────────────────────────────────────────────────────────────────────────────
//  PdfSurface.qml — PDF-Anzeige in 100% QML (ersetzt PdfViewer(QWidget)+
//  PdfWidgets). Bewusst KEIN PdfMultiPageView: ein eigener vertikaler ListView
//  aus PdfPageImage gibt volle Kontrolle über die Seitengeometrie, damit das
//  Annotations-Overlay (aus dem C++-Backend PdfMediaHandler, via
//  Viewer.pdfAnnotations exponiert) bei Scroll/Zoom exakt sitzt.
//
//  Seitenzentrierung + Scroll-Reflow: jede Seite wird auf die View-Breite
//  skaliert (× Zoom) und horizontal zentriert; das ListView kümmert sich um den
//  Reflow. RAM-Prio: nur sichtbare Seiten werden gerendert (ListView recycelt).
// ─────────────────────────────────────────────────────────────────────────────
Item {
    id: root

    property string source: ""
    property real   zoom: 1.0
    property var    annotations: []

    function release() {
        mediaLoader.active = false
        audioPlayer.stop()
        doc.source = ""
        annotations = []
    }

    onSourceChanged: {
        if (source.length > 0) {
            doc.source = root.source.indexOf("file:") === 0
                         ? root.source : "file://" + root.source
            annotations = Viewer.pdfAnnotations(root.source)
        } else {
            release()
        }
    }

    Rectangle { anchors.fill: parent; color: "#2b2b2b" }

    PdfDocument {
        id: doc
        onStatusChanged: if (status === PdfDocument.Error) errLabel.visible = true
    }

    Text {
        id: errLabel
        anchors.centerIn: parent
        visible: false
        text: "PDF konnte nicht geladen werden."
        color: "#ff8a80"; font.pixelSize: 14
    }

    // ── Seiten ───────────────────────────────────────────────────────────────
    ListView {
        id: pages
        anchors.fill: parent
        anchors.bottomMargin: audioBar.visible ? audioBar.height : 0
        clip: true
        model: doc.status === PdfDocument.Ready ? doc.pageCount : 0
        spacing: 10
        cacheBuffer: 0                       // RAM-Prio: keine Vorab-Seiten
        boundsBehavior: Flickable.StopAtBounds
        ScrollBar.vertical: ScrollBar { policy: ScrollBar.AsNeeded }

        delegate: Item {
            id: pageCell
            required property int index
            width: pages.width

            readonly property size pts: doc.pagePointSize(index)
            readonly property real fitScale: pts.width > 0 ? (pages.width - 24) / pts.width : 1.0
            readonly property real pageW: pts.width  * fitScale * root.zoom
            readonly property real pageH: pts.height * fitScale * root.zoom
            height: pageH + 4

            PdfPageImage {
                id: pageImg
                document: doc
                currentFrame: pageCell.index
                anchors.horizontalCenter: parent.horizontalCenter
                width: pageCell.pageW
                height: pageCell.pageH
                asynchronous: true
                cache: false
                fillMode: Image.PreserveAspectFit
                sourceSize.width: pageCell.pageW * Screen.devicePixelRatio
                sourceSize.height: pageCell.pageH * Screen.devicePixelRatio

                // ── Annotations-Overlay (normalisierte Rechtecke, y=0 oben) ──
                Repeater {
                    model: root.annotations
                    delegate: Rectangle {
                        id: badge
                        required property var modelData
                        visible: modelData.page === pageCell.index
                        x: modelData.x * pageImg.width
                        y: modelData.y * pageImg.height
                        width:  Math.max(18, modelData.w * pageImg.width)
                        height: Math.max(18, modelData.h * pageImg.height)
                        radius: 4
                        color: badgeHover.hovered ? Qt.rgba(0.0, 0.78, 0.70, 0.35)
                                                  : Qt.rgba(0.0, 0.78, 0.70, 0.18)
                        border.color: "#00c8b4"; border.width: 1

                        Text {
                            anchors.centerIn: parent
                            text: badge.modelData.type === 0 ? "\u266A"        // Audio
                                : badge.modelData.type === 1 ? "\u25B6"        // Video
                                : "\u2197"                                // Link
                            color: "#e0fffb"; font.pixelSize: 13
                        }
                        HoverHandler { id: badgeHover }
                        ToolTip.visible: badgeHover.hovered && badge.modelData.label.length > 0
                        ToolTip.text: badge.modelData.label

                        TapHandler {
                            onTapped: root.activateAnnotation(badge.modelData)
                        }
                    }
                }
            }
        }
    }

    function activateAnnotation(a) {
        if (a.type === 2 || a.uri.indexOf("http") === 0) {       // Link
            Viewer.openExternally(a.uri)
        } else if (a.type === 1) {                                // Video
            mediaLoader.uri = a.uri
            mediaLoader.active = true
        } else if (a.type === 0) {                                // Audio
            audioPlayer.source = a.uri.indexOf("file:") === 0 ? a.uri : "file://" + a.uri
            audioBar.label = a.label.length > 0 ? a.label : "Audio"
            audioPlayer.play()
        }
    }

    // ── Zoom-Steuerung ────────────────────────────────────────────────────────
    Row {
        anchors.bottom: parent.bottom
        anchors.right: parent.right
        anchors.margins: 14
        anchors.bottomMargin: (audioBar.visible ? audioBar.height : 0) + 14
        spacing: 8
        Rectangle {
            width: 36; height: 36; radius: 18; color: Qt.rgba(0,0,0,0.55)
            Text { anchors.centerIn: parent; text: "\u2212"; color: "white"; font.pixelSize: 18 }
            TapHandler { onTapped: root.zoom = Math.max(0.25, root.zoom - 0.2) }
        }
        Rectangle {
            width: 36; height: 36; radius: 18; color: Qt.rgba(0,0,0,0.55)
            Text { anchors.centerIn: parent; text: "+"; color: "white"; font.pixelSize: 18 }
            TapHandler { onTapped: root.zoom = Math.min(4.0, root.zoom + 0.2) }
        }
    }

    // ── Video-Overlay (Annotation) ─────────────────────────────────────────────
    Loader {
        id: mediaLoader
        anchors.fill: parent
        active: false
        property string uri: ""
        sourceComponent: Rectangle {
            color: Qt.rgba(0, 0, 0, 0.92)
            VideoSurface {
                anchors.fill: parent
                anchors.margins: 24
                source: mediaLoader.uri
            }
            Rectangle {
                anchors.top: parent.top; anchors.right: parent.right; anchors.margins: 16
                width: 40; height: 40; radius: 20; color: Qt.rgba(1,1,1,0.12)
                Text { anchors.centerIn: parent; text: "\u2715"; color: "white"; font.pixelSize: 18 }
                TapHandler { onTapped: mediaLoader.active = false }
            }
        }
    }

    // ── Audio-Leiste (Annotation) ──────────────────────────────────────────────
    MediaPlayer {
        id: audioPlayer
        audioOutput: AudioOutput { id: audioOut }
    }
    Rectangle {
        id: audioBar
        property string label: ""
        anchors { left: parent.left; right: parent.right; bottom: parent.bottom }
        height: 46
        visible: audioPlayer.playbackState !== MediaPlayer.StoppedState
        color: Qt.rgba(0, 0, 0, 0.8)
        Row {
            anchors.fill: parent; anchors.leftMargin: 12; anchors.rightMargin: 12; spacing: 10
            ToolButton {
                anchors.verticalCenter: parent.verticalCenter
                text: audioPlayer.playbackState === MediaPlayer.PlayingState ? "\u23F8" : "\u25B6"
                onClicked: audioPlayer.playbackState === MediaPlayer.PlayingState
                           ? audioPlayer.pause() : audioPlayer.play()
            }
            Text {
                anchors.verticalCenter: parent.verticalCenter
                text: audioBar.label; color: "white"; font.pixelSize: 12
                elide: Text.ElideRight; width: 160
            }
            Slider {
                anchors.verticalCenter: parent.verticalCenter
                width: parent.width - 280
                from: 0; to: Math.max(1, audioPlayer.duration)
                value: pressed ? value : audioPlayer.position
                onMoved: audioPlayer.position = value
            }
            ToolButton {
                anchors.verticalCenter: parent.verticalCenter
                text: "\u2715"
                onClicked: audioPlayer.stop()
            }
        }
    }
}
