pragma ComponentBehavior: Bound
import QtQuick
import QtQuick.Controls
import MediaGallery 1.0

// ─────────────────────────────────────────────────────────────────────────────
//  FilterBar.qml — Filter-/Sortierleiste (ersetzt FilterBar(QWidget)).
//
//  Bindet ausschließlich serverseitig an den Proxy (galleryModel): Sortierfeld +
//  -reihenfolge, Medientyp-Filter, Tag-Filtermodus (OR/AND/NUR/INKLUSIV), aktive
//  Tag-Chips (manuelle Tags). Der Kategorie-Filter lebt im TagCategoryPanel, das
//  über categoryToggleRequested geöffnet wird. Keine Filterlogik in QML.
// ─────────────────────────────────────────────────────────────────────────────
Rectangle {
    id: bar
    implicitHeight: 46
    color: App.themeFilterBarBg

    signal enterAddToTagMode(string tag)
    signal categoryPanelToggled()

    // Lokaler Spiegel der manuellen Tag-Auswahl → galleryModel.tagFilter.
    property var activeTags: []

    readonly property var modeNames: ["ODER", "UND", "NUR", "INKLUSIV"]
    readonly property var modeColors: ["#6ab0ff", "#00c8b4", "#ff9060", "#c090ff"]

    function toggleTag(tag) {
        var a = activeTags.slice()
        var i = a.indexOf(tag)
        if (i >= 0) a.splice(i, 1); else a.push(tag)
        activeTags = a
        galleryModel.tagFilter = a
    }
    function clearTags() { activeTags = []; galleryModel.tagFilter = [] }

    Rectangle {
        anchors.bottom: parent.bottom
        width: parent.width; height: 1
        color: App.themeBorder
    }

    Row {
        anchors.fill: parent
        anchors.leftMargin: 10
        anchors.rightMargin: 10
        spacing: 8

        // ── Sortierfeld ───────────────────────────────────────────────────────
        Text {
            anchors.verticalCenter: parent.verticalCenter
            text: "Sortieren:"; color: App.themeTextMuted; font.pixelSize: 12
        }
        ComboBox {
            id: sortField
            anchors.verticalCenter: parent.verticalCenter
            width: 130
            model: ["Datum", "Name", "Tags", "Dateigröße"]
            currentIndex: galleryModel.sortRole
            onActivated: galleryModel.sortRole = currentIndex
        }
        ToolButton {
            anchors.verticalCenter: parent.verticalCenter
            text: galleryModel.sortDescending ? "\u2193" : "\u2191"
            ToolTip.text: galleryModel.sortDescending ? "Absteigend" : "Aufsteigend"
            ToolTip.visible: hovered
            onClicked: galleryModel.sortDescending = !galleryModel.sortDescending
        }

        ToolSeparator { anchors.verticalCenter: parent.verticalCenter }

        // ── Medientyp-Filter ──────────────────────────────────────────────────
        Row {
            anchors.verticalCenter: parent.verticalCenter
            spacing: 4
            Repeater {
                model: [
                    { label: "Bilder", key: 0 },
                    { label: "Videos", key: 1 },
                    { label: "Audio",  key: 2 },
                    { label: "PDF",    key: 3 },
                    { label: "Text",   key: 4 }
                ]
                delegate: Button {
                    id: typeBtn
                    required property var modelData
                    height: 28
                    checkable: true
                    text: modelData.label
                    font.pixelSize: 11
                    checked: {
                        switch (modelData.key) {
                        case 0: return galleryModel.showImages
                        case 1: return galleryModel.showVideos
                        case 2: return galleryModel.showAudio
                        case 3: return galleryModel.showPdfs
                        default: return galleryModel.showTexts
                        }
                    }
                    onClicked: {
                        switch (modelData.key) {
                        case 0: galleryModel.showImages = checked; break
                        case 1: galleryModel.showVideos = checked; break
                        case 2: galleryModel.showAudio  = checked; break
                        case 3: galleryModel.showPdfs   = checked; break
                        default: galleryModel.showTexts = checked
                        }
                    }
                }
            }
        }

        ToolSeparator { anchors.verticalCenter: parent.verticalCenter }

        // ── Tag-Filtermodus (OR/AND/NUR/INKLUSIV) ─────────────────────────────
        Button {
            id: modeBtn
            anchors.verticalCenter: parent.verticalCenter
            height: 28
            text: bar.modeNames[galleryModel.tagFilterMode]
            font.pixelSize: 11; font.bold: true
            palette.buttonText: bar.modeColors[galleryModel.tagFilterMode]
            ToolTip.text: "Tag-Filter: UND=alle, ODER=mind. einer, NUR=ausschließlich diese, INKLUSIV=hat diesen"
            ToolTip.visible: hovered
            onClicked: modeMenu.open()
            Menu {
                id: modeMenu
                Repeater {
                    model: bar.modeNames
                    delegate: MenuItem {
                        required property int index
                        required property var modelData
                        text: modelData
                        onTriggered: galleryModel.tagFilterMode = index
                    }
                }
            }
        }

        // ── Tag-Auswahl ───────────────────────────────────────────────────────
        Button {
            anchors.verticalCenter: parent.verticalCenter
            height: 28
            text: "Tags \u25BE"; font.pixelSize: 11
            onClicked: tagMenu.open()
            Menu {
                id: tagMenu
                Repeater {
                    model: App.allTags()
                    delegate: MenuItem {
                        required property var modelData
                        text: modelData
                        checkable: true
                        checked: bar.activeTags.indexOf(modelData) >= 0
                        onTriggered: bar.toggleTag(modelData)
                    }
                }
            }
        }

        // ── Kategorie-Panel-Toggle ────────────────────────────────────────────
        Button {
            anchors.verticalCenter: parent.verticalCenter
            height: 28
            text: "Kategorien"; font.pixelSize: 11
            onClicked: bar.categoryPanelToggled()
        }

        // ── Aktive Tag-Chips ──────────────────────────────────────────────────
        Row {
            anchors.verticalCenter: parent.verticalCenter
            spacing: 4
            Repeater {
                model: bar.activeTags
                delegate: Rectangle {
                    id: chip
                    required property var modelData
                    height: 24; radius: 12
                    width: chipRow.implicitWidth + 16
                    color: Qt.rgba(App.tagColor(chip.modelData).r, App.tagColor(chip.modelData).g,
                                   App.tagColor(chip.modelData).b, 0.25)
                    border.color: App.tagColor(chip.modelData); border.width: 1
                    Row {
                        id: chipRow
                        anchors.centerIn: parent; spacing: 5
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            text: chip.modelData; color: App.themeTextPrimary; font.pixelSize: 11
                        }
                        Text {
                            anchors.verticalCenter: parent.verticalCenter
                            text: "\u2715"; color: App.themeTextMuted; font.pixelSize: 10
                            TapHandler { onTapped: bar.toggleTag(chip.modelData) }
                        }
                    }
                    TapHandler {
                        acceptedButtons: Qt.RightButton
                        onTapped: bar.enterAddToTagMode(chip.modelData)
                    }
                }
            }
            Text {
                visible: bar.activeTags.length > 0
                anchors.verticalCenter: parent.verticalCenter
                text: "Leeren"; color: App.themeAccent; font.pixelSize: 11
                TapHandler { onTapped: bar.clearTags() }
            }
        }
    }
}
