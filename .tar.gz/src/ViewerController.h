#pragma once
#include <QObject>
#include <QString>
#include <QVariantList>
#include <QHash>

class QPdfDocument;
class PdfMediaHandler;

// ─────────────────────────────────────────────────────────────────────────────
//  ViewerController — C++→QML-Bridge (Singleton) für die Viewer-Hilfsdienste,
//  die kein reines Property/Model sind:
//
//   • readTextFile(path)  → Datei-Inhalt (UTF-8, größenbegrenzt) für TextSurface.
//   • openExternally(path)→ Öffnet Medium im System-Standardprogramm (Video-Mode
//                           "external").
//   • pdfAnnotations(path)→ Medien-/Link-Annotationen eines PDFs als normalisierte
//                           Rechtecke; der C++-Backend-Scanner PdfMediaHandler
//                           bleibt unverändert und wird hier nach QML exponiert.
//                           Extrahierte Temp-Dateien leben bis zum App-Ende
//                           (PdfSurface spielt sie über MediaPlayer ab).
//
//  Registrierung via qmlRegisterSingletonInstance(…,"Viewer",…) in main.cpp.
// ─────────────────────────────────────────────────────────────────────────────
class ViewerController : public QObject {
    Q_OBJECT
public:
    explicit ViewerController(QObject* parent = nullptr);
    ~ViewerController() override;

    // Liest eine Textdatei (max. ~8 MB) als UTF-8 (mit Latin-1-Fallback).
    Q_INVOKABLE QString readTextFile(const QString& filePathOrUrl) const;

    // Öffnet das Medium im System-Standardprogramm. true bei Erfolg.
    Q_INVOKABLE bool openExternally(const QString& filePathOrUrl) const;

    // Medien-/Link-Annotationen für ein PDF. Liste von Maps:
    //   { page:int, x:real, y:real, w:real, h:real,  // normalisiert [0..1], y=0 oben
    //     type:int,    // 0=Audio,1=Video,2=Link,3=Unknown
    //     uri:string,  // lokaler Temp-Pfad oder externe URL
    //     label:string }
    Q_INVOKABLE QVariantList pdfAnnotations(const QString& filePathOrUrl);

private:
    static QString toLocalPath(const QString& filePathOrUrl);

    struct PdfEntry {
        QPdfDocument*    doc     = nullptr;
        PdfMediaHandler* handler = nullptr;
    };
    QHash<QString, PdfEntry> m_pdfCache;   // Pfad → geladenes Dokument + Scanner
};
