#include "ViewerController.h"
#include "PdfMediaHandler.h"

#include <QPdfDocument>
#include <QFile>
#include <QFileInfo>
#include <QUrl>
#include <QDesktopServices>
#include <QStringDecoder>
#include <QVariantMap>

ViewerController::ViewerController(QObject* parent) : QObject(parent) {}

ViewerController::~ViewerController() {
    // doc/handler sind QObject-Kinder von 'this' und werden vom Basis-Destruktor
    // gelöscht; hier nur die extrahierten Temp-Dateien entfernen.
    for (auto& e : m_pdfCache)
        if (e.handler) e.handler->cleanup();
    m_pdfCache.clear();
}

QString ViewerController::toLocalPath(const QString& s) {
    if (s.startsWith(QLatin1String("file:")))
        return QUrl(s).toLocalFile();
    return s;
}

QString ViewerController::readTextFile(const QString& filePathOrUrl) const {
    const QString path = toLocalPath(filePathOrUrl);
    QFile f(path);
    if (!f.open(QIODevice::ReadOnly))
        return {};

    constexpr qint64 kMaxBytes = 8 * 1024 * 1024;   // 8 MB Schutzgrenze
    const QByteArray raw = f.read(kMaxBytes);
    f.close();

    // UTF-8 mit Fehlerprüfung; bei ungültigen Sequenzen Latin-1-Fallback.
    QStringDecoder dec(QStringDecoder::Utf8);
    QString text = dec.decode(raw);
    if (dec.hasError())
        text = QString::fromLatin1(raw);

    if (f.size() > kMaxBytes)
        text += QStringLiteral("\n\n… [Datei gekürzt: > 8 MB]");
    return text;
}

bool ViewerController::openExternally(const QString& filePathOrUrl) const {
    const QString path = toLocalPath(filePathOrUrl);
    return QDesktopServices::openUrl(QUrl::fromLocalFile(path));
}

QVariantList ViewerController::pdfAnnotations(const QString& filePathOrUrl) {
    const QString path = toLocalPath(filePathOrUrl);
    if (path.isEmpty() || !QFileInfo::exists(path))
        return {};

    PdfEntry entry = m_pdfCache.value(path);
    if (!entry.handler) {
        entry.doc = new QPdfDocument(this);
        if (entry.doc->load(path) != QPdfDocument::Error::None
            || entry.doc->status() != QPdfDocument::Status::Ready) {
            delete entry.doc;
            return {};
        }
        entry.handler = new PdfMediaHandler(entry.doc, this);
        entry.handler->scanDocument(path);
        m_pdfCache.insert(path, entry);
    }

    QVariantList out;
    const QVector<MediaAnnotation>& anns = entry.handler->allAnnotations();
    out.reserve(anns.size());
    for (const MediaAnnotation& a : anns) {
        QVariantMap m;
        m.insert("page",  a.page);
        m.insert("x",     a.rect.x());
        m.insert("y",     a.rect.y());
        m.insert("w",     a.rect.width());
        m.insert("h",     a.rect.height());
        m.insert("type",  static_cast<int>(a.type));
        m.insert("uri",   a.resolvedUri());
        m.insert("label", a.label);
        out.append(m);
    }
    return out;
}
